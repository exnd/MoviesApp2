package com.example.moviesapp2;

public interface RecyclerViewInterface {

    void onItemClick(int position);
    void onHapusClick(int position);
}
