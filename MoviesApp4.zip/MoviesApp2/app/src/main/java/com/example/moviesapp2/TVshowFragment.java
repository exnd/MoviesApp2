package com.example.moviesapp2;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class TVshowFragment extends Fragment {

    View view;
    private RecyclerView rvMovies;
    private ArrayList<Movie> list = new ArrayList<>();
    private MainViewModel2 mainViewModel2;
    private ProgressBar progressBar;

    public TVshowFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mainViewModel2 = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(MainViewModel2.class);

        mainViewModel2.setWeather();


        view = inflater.inflate(R.layout.fragment_home,container,false);

        rvMovies = view.findViewById(R.id.rv_heroes);
        progressBar = view.findViewById(R.id.progressBar);

        final ListMovieAdapter listMovieAdapter = new ListMovieAdapter(list);

        rvMovies.setLayoutManager(new LinearLayoutManager(getActivity()));
        listMovieAdapter.notifyDataSetChanged();
        rvMovies.setAdapter(listMovieAdapter);
        showLoading(true);

        mainViewModel2.getWeathers().observe(this, new Observer<ArrayList<Movie>>() {
            @Override
            public void onChanged(ArrayList<Movie> listMovie2) {
                if (listMovie2 != null) {
                    showLoading(false);
                    listMovieAdapter.setData(listMovie2);

                }
            }
        });

        return view;


    }

    private void showLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    progressBar.setVisibility(View.GONE);
                }
            }, 500);

        }
    }

}
